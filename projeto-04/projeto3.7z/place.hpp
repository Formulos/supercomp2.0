
#ifndef place_if
#define place_if



class place {
    // variáveis declaradas aqui são privadas por padrão
    ;
    public:
        // variáveis declaradas aqui são públicas
        double posx;
        double posy;
        place();
        void add_point(double,double);
        
};

#endif